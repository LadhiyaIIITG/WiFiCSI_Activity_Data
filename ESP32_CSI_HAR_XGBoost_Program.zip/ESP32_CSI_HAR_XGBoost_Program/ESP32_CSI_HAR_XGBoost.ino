// ================================================================
//  ESP32 CSI — HUMAN ACTIVITY RECOGNITION  (6 Activities)
//  EMPTY | SITTING | SLOW_MOVEMENT | STANDING | WALKING | RUNNING
//  + TCS34725 lux sensor + Q-learning PWM lighting control (GPIO18)
//
//  Feature ranges from real data:
//    SITTING      : Var 0.22–1.80 | Range  2–7   | Peaks  3–10
//    SLOW_MOVEMENT: Var 0.32–3.50 | Range  2–9   | Peaks  6–13
//    STANDING     : Var 2.00–5.50 | Range  5–12  | Peaks  5–13
//    WALKING      : Var 3.50–9.70 | Range  7–15  | Peaks  5–13
//    RUNNING      : Var 7.00–17.3 | Range 11–16  | Peaks  5–11
//    EMPTY        : Var near baseline, Range < 4
// ================================================================

#include "WiFi.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <math.h>

// ---- light sensor + I2C ----
#include <Wire.h>
#include "Adafruit_TCS34725.h"

// ---- XGBoost-style tree ensemble, exported from MATLAB ----
#include "xgb_model.h"

#define USE_XGBOOST_CLASSIFIER 1

// ================================================================
//  CONFIGURATION  — edit only these lines
// ================================================================

#define WIFI_SSID  "LadhiyaDell"
#define WIFI_PASS  "Hl860210"
#define ROUTER_IP  "192.168.1.1"     

String GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbx5gWyfxS8Rw3ySyPVlWYNswROo6-JwZ0e5oqsCQFZMm9eDEhMa5ehRlaMQXrGeAvMFOw/exec";

// ================================================================
//  TIMING
// ================================================================

#define SERIAL_INTERVAL_MS   4000    // serial print every 4 s
#define UPLOAD_INTERVAL_MS   5000    // Google Sheets every 5 s

// ================================================================
//  WINDOW
// ================================================================

#define WINDOW_SIZE  40

float  win[WINDOW_SIZE];
int    winIdx  = 0;
bool   winFull = false;

// ================================================================
//  SIGNAL FEATURES  (computed inside CSI callback)
// ================================================================

float prev         = 0.0f;
float currentVar   = 0.0f;
float currentMean  = 0.0f;
float currentPeak  = 0.0f;
float currentStd   = 0.0f;
float currentRange = 0.0f;

// ================================================================
//  PACKET COUNTERS
// ================================================================

unsigned long packetCount     = 0;
unsigned long lastPacketCount = 0;
unsigned long pps             = 0;
unsigned long lastPpsTime     = 0;
int           curPktLen       = 0;
int           curSubcarriers  = 0;

// ================================================================
//  LAST CLASSIFIED ACTIVITY
// ================================================================

String lastActivity     = "SLOW_MOVEMENT";
String lastRuleActivity = "SLOW_MOVEMENT";
String lastXgbActivity  = "SLOW_MOVEMENT";

// ================================================================
//  ADAPTIVE VARIANCE BASELINE  (EMPTY detection)
// ================================================================

#define VAR_HIST_SIZE  10

float varHist[VAR_HIST_SIZE];
int   varHistIdx   = 0;
bool  varBaseReady = false;
float varBaseline  = 999.0f;

// ================================================================
//  ADAPTIVE PEAK BASELINE
// ================================================================

#define PEAK_HIST_SIZE  10

float peakHist[PEAK_HIST_SIZE];
int   peakHistIdx = 0;
float peakBase    = 7.0f;

// ================================================================
//  TCS34725 LIGHT SENSOR + PWM LIGHTING CONTROL
// ================================================================

Adafruit_TCS34725 tcs = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_50MS,
                                           TCS34725_GAIN_4X);
bool tcsReady = false;

#define PWM_PIN_1     18
#define PWM_CHANNEL_1 0
#define PWM_FREQ_HZ   2000
#define PWM_RES_BITS  8

float pwmDutyPercent = 0.0f;

float targetLux   = 0.0f;
float measuredLux = 0.0f;
float luxError    = 0.0f;

// ================================================================
//  Q-LEARNING AGENT
//  State  : detected activity, 6 states
//           S0 EMPTY | S1 SITTING | S2 STANDING
//           S3 WALKING | S4 RUNNING | S5 SLOW_MOVEMENT
//  Action : PWM duty in 10% steps, 11 actions (A0=0% ... A10=100%)
//  Reward : 100 − 0.3×|LuxError| − 0.2×PWM(%)
// ================================================================

#define STATE_COUNT   6
#define ACTION_COUNT  11

float Q[STATE_COUNT][ACTION_COUNT];
unsigned int visitCount[STATE_COUNT][ACTION_COUNT];

const float ALPHA        = 0.10f;
const float GAMMA        = 0.90f;
float       epsilon      = 0.20f;
const float EPSILON_MIN  = 0.05f;
const float EPSILON_DECAY = 0.999f;

int   prevState         = -1;
int   prevAction        = -1;
float prevReward        = 0.0f;
bool  havePendingUpdate = false;

unsigned long qStepCount = 0;
float         rewardSum  = 0.0f;

float getTargetLuxForActivity(String activity)
{
    if (activity == "EMPTY")          return 0.0f;
    if (activity == "STANDING")       return 400.0f;
    if (activity == "SITTING")        return 550.0f;
    if (activity == "SLOW_MOVEMENT")  return 700.0f;
    if (activity == "WALKING")        return 300.0f;
    if (activity == "RUNNING")        return 450.0f;
    return 400.0f;
}

float readLuxFromSensor()
{
    if (!tcsReady) return 0.0f;

    uint16_t r, g, b, c;
    tcs.getRawData(&r, &g, &b, &c);

    float lux = tcs.calculateLux(r, g, b);
    if (isnan(lux) || lux < 0.0f) lux = 0.0f;
    return lux;
}

int percentToDuty255(float percent)
{
    int duty255 = (int)((percent / 100.0f) * 255.0f + 0.5f);
    if (duty255 > 255) duty255 = 255;
    if (duty255 < 0)   duty255 = 0;
    return duty255;
}

int activityToState(String activity)
{
    if (activity == "EMPTY")          return 0;
    if (activity == "SITTING")        return 1;
    if (activity == "STANDING")       return 2;
    if (activity == "WALKING")        return 3;
    if (activity == "RUNNING")        return 4;
    if (activity == "SLOW_MOVEMENT")  return 5;
    return 1;
}

float actionToPercent(int action)
{
    return (float)action * 10.0f;
}

float maxQ(int state)
{
    float best = Q[state][0];
    for (int a = 1; a < ACTION_COUNT; a++)
        if (Q[state][a] > best) best = Q[state][a];
    return best;
}

int chooseAction(int state)
{
    for (int a = 0; a < ACTION_COUNT; a++)
        if (visitCount[state][a] == 0) return a;

    float r = random(0, 10000) / 10000.0f;
    if (r < epsilon) return random(0, ACTION_COUNT);

    float bestQ = Q[state][0];
    for (int a = 1; a < ACTION_COUNT; a++)
        if (Q[state][a] > bestQ) bestQ = Q[state][a];

    int candidates[ACTION_COUNT];
    int nCandidates = 0;
    for (int a = 0; a < ACTION_COUNT; a++)
        if (fabsf(Q[state][a] - bestQ) < 0.001f) candidates[nCandidates++] = a;

    return candidates[random(0, nCandidates)];
}

float computeReward(float luxErr, float pwmPercent)
{
    return 100.0f - 0.3f * fabsf(luxErr) - 0.2f * pwmPercent;
}

void runQLearningControl(String activity)
{
    int state = activityToState(activity);
    targetLux = getTargetLuxForActivity(activity);

    if (havePendingUpdate)
    {
        float bootstrap = maxQ(state);
        Q[prevState][prevAction] +=
            ALPHA * (prevReward + GAMMA * bootstrap - Q[prevState][prevAction]);
    }

    int action = chooseAction(state);
    visitCount[state][action]++;
    pwmDutyPercent = actionToPercent(action);

    int duty255 = percentToDuty255(pwmDutyPercent);
    ledcWrite(PWM_CHANNEL_1, duty255);

    delay(1500);

    measuredLux = readLuxFromSensor();
    luxError    = targetLux - measuredLux;
    float reward = computeReward(luxError, pwmDutyPercent);

    prevState         = state;
    prevAction         = action;
    prevReward         = reward;
    havePendingUpdate  = true;

    qStepCount++;
    rewardSum += reward;

    epsilon *= EPSILON_DECAY;
    if (epsilon < EPSILON_MIN) epsilon = EPSILON_MIN;
}

// ================================================================
//  CSI CALLBACK
// ================================================================

void wifi_csi_rx_cb(void *ctx, wifi_csi_info_t *data)
{
    packetCount++;
    curPktLen      = data->len;
    curSubcarriers = data->len / 2;

    int    len = data->len;
    int8_t *buf = data->buf;
    float  sum  = 0.0f;

    for (int i = 0; i < len; i += 2)
    {
        float amp = sqrt((float)(buf[i] * buf[i] + buf[i+1] * buf[i+1]));
        sum += amp;
    }

    float avg      = sum / (len / 2);
    float smoothed = 0.65f * prev + 0.35f * avg;
    prev = smoothed;

    win[winIdx++] = smoothed;
    if (winIdx >= WINDOW_SIZE) { winIdx = 0; winFull = true; }
    if (!winFull) return;

    float mean = 0.0f;
    for (int i = 0; i < WINDOW_SIZE; i++) mean += win[i];
    mean        /= WINDOW_SIZE;
    currentMean  = mean;

    float var = 0.0f;
    for (int i = 0; i < WINDOW_SIZE; i++)
        var += (win[i] - mean) * (win[i] - mean);
    var        /= WINDOW_SIZE;
    currentVar  = var;

    currentStd = sqrt(var);

    float lo = win[0], hi = win[0];
    for (int i = 1; i < WINDOW_SIZE; i++)
    {
        if (win[i] < lo) lo = win[i];
        if (win[i] > hi) hi = win[i];
    }
    currentRange = hi - lo;

    int peaks = 0;
    for (int i = 1; i < WINDOW_SIZE - 1; i++)
    {
        float d1 = win[i] - win[i-1];
        float d2 = win[i] - win[i+1];
        if (d1 > 0.15f && d2 > 0.15f) peaks++;
    }
    currentPeak = (float)peaks;
}


void generateTraffic()
{
    WiFiClient c1;
    if (c1.connect(ROUTER_IP, 80))
    {
        c1.print("GET / HTTP/1.1\r\nHost: " ROUTER_IP "\r\nConnection: close\r\n\r\n");
        delay(5);
        c1.stop();
    }

    WiFiClient c2;
    if (c2.connect("142.250.80.46", 80))
    {
        c2.print("GET / HTTP/1.1\r\nHost: google.com\r\nConnection: close\r\n\r\n");
        delay(5);
        c2.stop();
    }
}

// ================================================================
//  CLASSIFY ACTIVITY
// ================================================================

String classifyActivity()
{
    varHist[varHistIdx % VAR_HIST_SIZE] = currentVar;
    varHistIdx++;
    if (varHistIdx >= VAR_HIST_SIZE) varBaseReady = true;

    if (varBaseReady)
    {
        float minV = varHist[0];
        for (int i = 1; i < VAR_HIST_SIZE; i++)
            if (varHist[i] > 0.0f && varHist[i] < minV)
                minV = varHist[i];
        varBaseline = minV;
    }

    if (currentVar < 2.0f)
    {
        peakHist[peakHistIdx % PEAK_HIST_SIZE] = currentPeak;
        peakHistIdx++;

        float sumP = 0.0f; int cnt = 0;
        for (int i = 0; i < PEAK_HIST_SIZE; i++)
            if (peakHist[i] > 0.0f) { sumP += peakHist[i]; cnt++; }
        if (cnt > 0) peakBase = sumP / cnt;
    }

    float pkSitMax   = peakBase + 3.0f;
    float pkSlowMax  = peakBase + 6.0f;
    float pkStandMax = peakBase + 6.0f;
    float pkWalkMax  = peakBase + 7.0f;

    float emptyVarMax = varBaseline * 1.30f;
    if (emptyVarMax > 1.0f) emptyVarMax = 1.0f;

    if (varBaseReady              &&
        currentVar   <= emptyVarMax   &&
        currentRange <  4.0f          &&
        currentPeak  <= (peakBase + 1.0f))
    {
        return "EMPTY";
    }

    if (currentVar   >= 7.0f &&
        currentRange >= 11.0f)
    {
        return "RUNNING";
    }

    if (currentVar   >= 3.5f   &&
        currentRange >= 7.5f   &&
        currentRange <  15.0f  &&
        currentPeak  <= pkWalkMax)
    {
        return "WALKING";
    }

    if (currentVar   >= 2.5f   &&
        currentVar   <  7.0f   &&
        currentRange >= 5.0f   &&
        currentRange <  12.5f  &&
        currentPeak  <= pkStandMax)
    {
        return "STANDING";
    }

    if (currentVar   <  1.8f  &&
        currentRange <  7.0f  &&
        currentPeak  <= pkSitMax)
    {
        return "SITTING";
    }

    return "SLOW_MOVEMENT";
}

// ================================================================
//  XGBOOST-STYLE CLASSIFIER  (weighted-vote tree ensemble)
//
//  Feature order MUST match train_xgboost_har_export.m's
//  featureNames / feature-matrix columns exactly:
//    Channel, PacketLength, Subcarriers, Packets, PacketsPerSec,
//    Variance, Mean, Peaks, StdDeviation, Range
// ================================================================

float xgbRawFeatures[XGB_NUM_FEATURES];
float xgbNormFeatures[XGB_NUM_FEATURES];
float xgbClassScore[XGB_NUM_CLASSES];

void buildFeatureVector()
{
    xgbRawFeatures[0] = (float)WiFi.channel();
    xgbRawFeatures[1] = (float)curPktLen;
    xgbRawFeatures[2] = (float)curSubcarriers;
    xgbRawFeatures[3] = (float)packetCount;
    xgbRawFeatures[4] = (float)pps;
    xgbRawFeatures[5] = currentVar;
    xgbRawFeatures[6] = currentMean;
    xgbRawFeatures[7] = currentPeak;
    xgbRawFeatures[8] = currentStd;
    xgbRawFeatures[9] = currentRange;
}

void normalizeFeatureVector()
{
    for (int i = 0; i < XGB_NUM_FEATURES; i++)
    {
        float sigma = (XGB_SIGMA[i] == 0.0f) ? 1.0f : XGB_SIGMA[i];
        xgbNormFeatures[i] = (xgbRawFeatures[i] - XGB_MU[i]) / sigma;
    }
}

int xgbEvalTree(int treeIdx)
{
    int32_t base  = XGB_TREE_START[treeIdx];
    int     local = 0;

    while (true)
    {
        const XgbNode &node = XGB_NODES[base + local];

        if (node.featureIdx < 0)
            return node.leafClass;

        if (xgbNormFeatures[node.featureIdx] <= node.threshold)
            local = node.left;
        else
            local = node.right;
    }
}


String classifyActivityXGB()
{
    buildFeatureVector();
    normalizeFeatureVector();

    for (int c = 0; c < XGB_NUM_CLASSES; c++) xgbClassScore[c] = 0.0f;

    for (int t = 0; t < XGB_NUM_TREES; t++)
    {
        int cls = xgbEvalTree(t);
        xgbClassScore[cls] += XGB_TREE_WEIGHT[t];
    }

    int best = 0;
    for (int c = 1; c < XGB_NUM_CLASSES; c++)
        if (xgbClassScore[c] > xgbClassScore[best]) best = c;

    return String(XGB_CLASS_NAMES[best]);
}

// ================================================================
//  SEND TO GOOGLE SHEETS
// ================================================================

void sendToGoogleSheets(String activity)
{
    if (WiFi.status() != WL_CONNECTED)
    {
        Serial.println("WiFi not connected — skipping upload");
        return;
    }

    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient https;

    String url = GOOGLE_SCRIPT_URL;

    url += "?activity=" + activity;
    url += "&targetlux=" + String(targetLux,1);
    url += "&measuredlux=" + String(measuredLux,1);
    url += "&luxerror=" + String(luxError,1);
    url += "&pwmduty=" + String((int)pwmDutyPercent);

    url += "&qstate=S" + String(prevState);

    url += "&qaction=A" + String(prevAction)
          + "%20(" + String(actionToPercent(prevAction))
          + "%25)";

    url += "&reward=" + String(prevReward,2);

    url += "&avgreward=" + String(
            (qStepCount>0)?
            (rewardSum/(float)qStepCount):0.0,2);

    url += "&epsilon=" + String(epsilon,3);

    url += "&qsteps=" + String(qStepCount);

    if (https.begin(client, url))
    {
        int code = https.GET();

        if (code > 0)
        {
            Serial.print("✅ Sheets upload OK  HTTP:");
            Serial.println(code);
        }
        else
        {
            Serial.print("❌ Upload failed  code:");
            Serial.println(code);
        }
        https.end();
    }
    else
    {
        Serial.println("❌ HTTPS connection failed");
    }
}

// ================================================================
//  SETUP
// ================================================================

void setup()
{
    Serial.begin(115200);
    delay(2000);

    for (int i = 0; i < VAR_HIST_SIZE;  i++) varHist[i]  = 0.0f;
    for (int i = 0; i < PEAK_HIST_SIZE; i++) peakHist[i] = 0.0f;

    randomSeed(esp_random());
    for (int s = 0; s < STATE_COUNT; s++)
    {
        for (int a = 0; a < ACTION_COUNT; a++)
        {
            Q[s][a] = 0.0f;
            visitCount[s][a] = 0;
        }
    }

    Serial.println();
    Serial.println("============================================");
    Serial.println("   ESP32 CSI — 6-ACTIVITY HAR SYSTEM v12");
    Serial.println("   EMPTY | SITTING | SLOW_MOVEMENT");
    Serial.println("   STANDING | WALKING | RUNNING");
    Serial.println("   + TCS34725 lux sensor + Q-learning lighting");
#if USE_XGBOOST_CLASSIFIER
    Serial.println("   Classifier: XGBoost-style boosted trees");
#else
    Serial.println("   Classifier: hand-tuned threshold rules");
#endif
    Serial.print  ("   Model      : "); Serial.print(XGB_NUM_TREES);
    Serial.print  (" trees x "); Serial.print(XGB_NUM_NODES);
    Serial.println(" nodes (exported from MATLAB)");
    Serial.println("============================================");

    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    Serial.print("Connecting to WiFi");
    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }
    Serial.println();
    Serial.println("WiFi Connected ✅");
    Serial.print("  IP      : "); Serial.println(WiFi.localIP());
    Serial.print("  Channel : "); Serial.println(WiFi.channel());
    Serial.println();

    esp_wifi_set_promiscuous(true);

    wifi_csi_config_t cfg;
    cfg.lltf_en           = true;
    cfg.htltf_en          = true;
    cfg.stbc_htltf2_en    = true;
    cfg.ltf_merge_en      = true;
    cfg.channel_filter_en = true;
    cfg.manu_scale        = false;
    cfg.shift             = false;

    esp_wifi_set_csi_config(&cfg);
    esp_wifi_set_csi_rx_cb(&wifi_csi_rx_cb, NULL);
    esp_wifi_set_csi(true);

    Serial.println("CSI Enabled ✅");

    Wire.begin();
    if (tcs.begin())
    {
        tcsReady = true;
        Serial.println("TCS34725 light sensor found ✅");
    }
    else
    {
        tcsReady = false;
        Serial.println("❌ TCS34725 not found — check wiring (SDA/SCL)");
    }

    ledcSetup(PWM_CHANNEL_1, PWM_FREQ_HZ, PWM_RES_BITS);
    ledcAttachPin(PWM_PIN_1, PWM_CHANNEL_1);

    ledcWrite(PWM_CHANNEL_1, 0);

    Serial.println("PWM lighting output ready on GPIO18 ✅");
    Serial.print("Q-learning agent ready: ");
    Serial.print(STATE_COUNT); Serial.print(" states x ");
    Serial.print(ACTION_COUNT); Serial.println(" actions ✅");
    Serial.println();

    Serial.println("--------------------------------------------");
    Serial.println("  CALIBRATION — do these steps in order:");
    Serial.println("  1. Leave room COMPLETELY EMPTY — 2 minutes");
    Serial.println("  2. SIT completely still  — 2 minutes");
    Serial.println("  3. Fidget / slow movement — 2 minutes");
    Serial.println("  4. STAND still           — 2 minutes");
    Serial.println("  5. WALK normally          — 2 minutes");
    Serial.println("  6. RUN / jog              — 2 minutes");
    Serial.println("--------------------------------------------");
    Serial.print("  Serial print  every : ");
    Serial.print(SERIAL_INTERVAL_MS / 1000);
    Serial.println(" s");
    Serial.print("  Google Sheets every : ");
    Serial.print(UPLOAD_INTERVAL_MS / 1000);
    Serial.println(" s");
    Serial.println("============================================");
    Serial.println();
}

// ================================================================
//  LOOP
// ================================================================

void loop()
{
    generateTraffic();

    if (millis() - lastPpsTime >= 1000)
    {
        pps = (packetCount >= lastPacketCount)
              ? (packetCount - lastPacketCount)
              : 0;
        lastPacketCount = packetCount;
        lastPpsTime     = millis();
    }

    static unsigned long lastUpload = 0;
    bool timeToUpload = (millis() - lastUpload > UPLOAD_INTERVAL_MS);

    if (timeToUpload)
    {
        // Both run every cycle: the rule-based classifier also keeps
        // its adaptive var/peak baselines updated for the diagnostic
        // print below, and running both lets you compare them live.
        lastRuleActivity = classifyActivity();
        lastXgbActivity  = classifyActivityXGB();

#if USE_XGBOOST_CLASSIFIER
        lastActivity = lastXgbActivity;
#else
        lastActivity = lastRuleActivity;
#endif

        lastUpload = millis();

        runQLearningControl(lastActivity);
    }

    static unsigned long lastPrint = 0;
    if (millis() - lastPrint > SERIAL_INTERVAL_MS)
    {
        Serial.println("============================================");
        Serial.print("  Channel      : "); Serial.println(WiFi.channel());
        Serial.print("  Pkt Length   : "); Serial.println(curPktLen);
        Serial.print("  Subcarriers  : "); Serial.println(curSubcarriers);
        Serial.print("  Total Pkts   : "); Serial.println(packetCount);
        Serial.print("  Pkts/sec     : "); Serial.println(pps);
        Serial.println("  ---");
        Serial.print("  Variance     : "); Serial.println(currentVar,   2);
        Serial.print("  Var Baseline : "); Serial.println(varBaseline,  2);
        Serial.print("  Mean         : "); Serial.println(currentMean,  2);
        Serial.print("  Std Dev      : "); Serial.println(currentStd,   2);
        Serial.print("  Range        : "); Serial.println(currentRange, 2);
        Serial.print("  Peaks        : "); Serial.println(currentPeak);
        Serial.print("  Peak Baseline: "); Serial.println(peakBase,     1);
        Serial.println("  ---");
        Serial.print("  Rule-based   : "); Serial.println(lastRuleActivity);
        Serial.print("  XGBoost      : "); Serial.println(lastXgbActivity);
        Serial.print("  ➡ Activity   : "); Serial.println(lastActivity);
        Serial.print("     (driven by: ");
#if USE_XGBOOST_CLASSIFIER
        Serial.print("XGBoost");
#else
        Serial.print("rule-based");
#endif
        Serial.println(")");
        Serial.println("  ---");
        Serial.print("  Target Lux   : "); Serial.println(targetLux,    1);
        Serial.print("  Measured Lux : "); Serial.println(measuredLux,  1);
        Serial.print("  Lux Error    : "); Serial.println(luxError,     1);
        Serial.print("  PWM Duty     : "); Serial.print(pwmDutyPercent, 0); Serial.println(" %");
        Serial.println("  ---");
        Serial.print("  Q-State      : S"); Serial.println(prevState);
        Serial.print("  Q-Action     : A"); Serial.print(prevAction);
        Serial.print("  ("); Serial.print(actionToPercent(prevAction), 0); Serial.println("%)");
        Serial.print("  Reward       : "); Serial.println(prevReward,   2);
        Serial.print("  Avg Reward   : "); Serial.println(qStepCount > 0 ? (rewardSum / qStepCount) : 0.0f, 2);
        Serial.print("  Epsilon      : "); Serial.println(epsilon,      3);
        Serial.print("  Q-Steps      : "); Serial.println(qStepCount);

        if (prevState >= 0)
        {
            int covered = 0;
            for (int a = 0; a < ACTION_COUNT; a++)
                if (visitCount[prevState][a] > 0) covered++;
            Serial.print("  S"); Serial.print(prevState);
            Serial.print(" Coverage   : "); Serial.print(covered);
            Serial.println(" / 11 actions tried");
        }

        Serial.println("============================================");
        Serial.println();

        lastPrint = millis();
    }

    if (timeToUpload)
    {
        sendToGoogleSheets(lastActivity);
    }

    delay(30);
}
